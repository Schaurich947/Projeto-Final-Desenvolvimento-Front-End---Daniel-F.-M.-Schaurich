ORGÂNICA SOLUÇÕES WEB - Projeto Final de Desenvolvimento Front-End
Aluno: DANIE LFELIPE MORAES SCHAURICH

COMO ABRIR
Abra o arquivo index.html no navegador (precisa de internet para carregar Bootstrap e fontes).

ESTRUTURA
index.html        -> página (HTML semântico)
css/style.css     -> CSS próprio (variáveis, card-organica, media queries)
js/script.js      -> validação do formulário, máscara de telefone, menu mobile
img/              -> imagens (SVG)
docs/wireframe.svg-> wireframe (planejamento da estrutura)