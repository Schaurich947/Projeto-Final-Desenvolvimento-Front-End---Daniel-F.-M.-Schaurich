(() => {
    'use strict';

    // 1. Ano atual no rodapé
    const ano = document.getElementById('ano');
    if (ano) ano.textContent = new Date().getFullYear();

    // 2. Fecha o menu mobile ao clicar em um link
    const menu = document.getElementById('menuPrincipal');
    if (menu) {
        menu.querySelectorAll('a').forEach((link) => {
            link.addEventListener('click', () => {
                if (menu.classList.contains('show')) {
                    bootstrap.Collapse.getOrCreateInstance(menu).hide();
                }
            });
        });
    }

    // 3. Máscara de telefone: (49) 99999-9999
    const telefone = document.getElementById('telefone');
    if (telefone) {
        telefone.addEventListener('input', () => {
            const d = telefone.value.replace(/\D/g, '').slice(0, 11);
            let texto = d;
            if (d.length > 10) {
                texto = `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
            } else if (d.length > 6) {
                texto = `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
            } else if (d.length > 2) {
                texto = `(${d.slice(0, 2)}) ${d.slice(2)}`;
            } else if (d.length > 0) {
                texto = `(${d}`;
            }
            telefone.value = texto;
        });
    }

    // 4. Validação do formulário (usa as classes de validação do Bootstrap)
    const form = document.getElementById('formContato');
    const sucesso = document.getElementById('mensagemSucesso');

    if (form) {
        form.addEventListener('submit', (evento) => {
            evento.preventDefault();

            if (!form.checkValidity()) {
                evento.stopPropagation();
                form.classList.add('was-validated');
                const primeiroInvalido = form.querySelector(':invalid');
                if (primeiroInvalido) primeiroInvalido.focus();
                return;
            }

            // Aqui entraria o envio real (fetch para um back-end ou serviço de e-mail).
            // Como o projeto é só front-end, apenas confirmamos o envio.
            form.reset();
            form.classList.remove('was-validated');
            sucesso.classList.remove('d-none');
            sucesso.focus();
        });
    }
})();
